# IP Addressing Plan

| Segment | Network | Gateway / Interface | Notes |
|---|---|---|---|
| IT VLAN 10 | 192.168.10.0/24 | 192.168.10.1 | DHCP |
| Administration VLAN 20 | 192.168.20.0/24 | 192.168.20.1 | DHCP |
| HR VLAN 30 | 192.168.30.0/24 | 192.168.30.1 | DHCP |
| Guest VLAN 40 | 192.168.40.0/24 | 192.168.40.1 | DHCP; restricted by ACL |
| Management VLAN 99 | 192.168.99.0/24 | 192.168.99.1 | Static switch management |
| R1–SW1 transit | 10.0.0.0/30 | R1 10.0.0.1; SW1 10.0.0.2 | OSPF area 0 |
| External test LAN | 203.0.113.0/24 | R1 203.0.113.1 | Documentation/test subnet |
| SRV-EXT | — | 203.0.113.10 | Static IP; gateway 203.0.113.1 |

DHCP excludes the first 20 addresses in each client VLAN to keep room for gateways, printers, and static infrastructure.
