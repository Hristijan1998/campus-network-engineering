# Topology and cabling

## Devices

| Hostname | Packet Tracer model | Role |
|---|---|---|
| R1 | Cisco 2911 | Edge router and OSPF peer |
| SW1 | Cisco 3560 | Multilayer core, SVIs, DHCP, ACLs |
| SW2 | Cisco 2960 | Access switch for IT and Administration |
| SW3 | Cisco 2960 | Access switch for HR and Guest |
| PC-IT | PC | VLAN 10 client |
| PC-ADMIN | PC | VLAN 20 client |
| PC-HR | PC | VLAN 30 client |
| PC-GUEST | PC | VLAN 40 client |
| SRV-EXT | Server | External-network test endpoint |

## Physical links

Use Copper Straight-Through cables (Packet Tracer's automatic connection can also select a suitable cable).

| Device A | Interface | Device B | Interface | Purpose |
|---|---|---|---|---|
| R1 | G0/0 | SW1 | G0/1 | Routed transit link |
| R1 | G0/1 | SRV-EXT | FastEthernet0 | External test LAN |
| SW1 | G0/2 | SW2 | G0/1 | 802.1Q trunk |
| SW1 | F0/1 | SW3 | G0/1 | 802.1Q trunk |
| SW2 | F0/1 | PC-IT | FastEthernet0 | VLAN 10 access |
| SW2 | F0/2 | PC-ADMIN | FastEthernet0 | VLAN 20 access |
| SW3 | F0/1 | PC-HR | FastEthernet0 | VLAN 30 access |
| SW3 | F0/2 | PC-GUEST | FastEthernet0 | VLAN 40 access |

## Design details

- SW1 routes between VLANs using switched virtual interfaces (SVIs).
- SW1 and R1 form an OSPF adjacency across `10.0.0.0/30`.
- R1 advertises the directly connected external test LAN `203.0.113.0/24` into OSPF.
- DHCP scopes live on SW1. Each client VLAN receives its own subnet and default gateway.
- VLAN 40 has an inbound ACL that denies access to `192.168.0.0/16`, then permits other IPv4 traffic. This blocks Guest access to the internal department and management networks while allowing the simulated external test network.
- VLAN 99 is reserved for switch management. In this compact lab, switch management addresses are assigned to SW2 and SW3 SVIs; management access from Guest is blocked by the ACL.

## Device interface caveat

Packet Tracer model/port availability may vary. If the switch doesn't have `FastEthernet0/1` or `GigabitEthernet0/2`, use another available port and update the corresponding configuration consistently.
