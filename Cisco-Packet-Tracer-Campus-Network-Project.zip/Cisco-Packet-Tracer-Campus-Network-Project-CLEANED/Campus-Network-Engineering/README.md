# Cisco Packet Tracer Campus Network

A portfolio-ready enterprise campus networking lab built with Cisco Packet Tracer. The project demonstrates VLAN segmentation, Layer 3 switching, inter-VLAN routing, DHCP, OSPF, trunk links, and ACL-based Guest network isolation.

## Project Overview

This lab represents a small enterprise campus network with separate departmental networks and a dedicated management VLAN. A multilayer switch performs inter-VLAN routing, while an edge router connects the campus to a simulated external test network.

**Project file:** `Campus-Network-Engineering.pkt`

## Objectives

- Create departmental VLANs and a management VLAN.
- Configure access ports and IEEE 802.1Q trunk links.
- Implement inter-VLAN routing on a multilayer switch.
- Provide DHCP addressing for client VLANs.
- Configure OSPF between the core switch and edge router.
- Isolate the Guest VLAN from internal networks using an extended ACL.
- Verify connectivity and document test results.
- Practice network configuration, troubleshooting, and documentation.

## Network Topology

The topology contains:

- **R1** — Cisco 2911 edge router
- **SW1** — Cisco 3560 multilayer switch
- **SW2** — Cisco 2960 access switch
- **SW3** — Cisco 2960 access switch
- **PC-IT** — IT department client
- **PC-ADMIN** — Administration department client
- **PC-HR** — HR department client
- **PC-GUEST** — Guest network client
- **SRV-EXT** — Simulated external test server

View the network diagram in [`topology/campus-topology.png`](topology/campus-topology.png) or read the detailed design in [`docs/TOPOLOGY.md`](docs/TOPOLOGY.md).

## VLAN and IP Addressing

| VLAN | Department | Network | Default Gateway |
|---:|---|---|---|
| 10 | IT | `192.168.10.0/24` | `192.168.10.1` |
| 20 | Administration | `192.168.20.0/24` | `192.168.20.1` |
| 30 | HR | `192.168.30.0/24` | `192.168.30.1` |
| 40 | Guest | `192.168.40.0/24` | `192.168.40.1` |
| 99 | Management | `192.168.99.0/24` | `192.168.99.1` |

**Router-to-switch transit network:** `10.0.0.0/30`

- R1: `10.0.0.1`
- SW1: `10.0.0.2`

**External test network:** `203.0.113.0/24`

- R1: `203.0.113.1`
- SRV-EXT: `203.0.113.10` (planned server address; verify the server configuration in Packet Tracer)

For the full addressing plan, see [`docs/IP-ADDRESSING.md`](docs/IP-ADDRESSING.md).

## Technologies and Features

- Cisco Packet Tracer
- VLANs and 802.1Q trunking
- Layer 2 switching and Layer 3 switching
- Switched Virtual Interfaces (SVIs)
- Inter-VLAN routing
- DHCP pools and excluded address ranges
- OSPF dynamic routing
- Extended IPv4 access control lists
- Spanning Tree Protocol and PortFast
- Network troubleshooting and verification

## Guest Network Security

The extended ACL `GUEST-IN` is applied inbound on SW1's VLAN 40 SVI. It denies traffic from the Guest subnet to the internal `192.168.0.0/16` address range and permits other IPv4 traffic from the Guest subnet.

This design is intended to prevent Guest clients from reaching the internal departmental and management networks while allowing traffic toward other destinations, subject to routing and the destination network's configuration.

## Configuration Files

Device configuration documentation is stored in [`configs/`](configs/):

- [`R1.txt`](configs/R1.txt) — Edge router, transit interface, external test interface, and OSPF
- [`SW1.txt`](configs/SW1.txt) — VLANs, SVIs, DHCP, inter-VLAN routing, Guest ACL, and OSPF
- [`SW2.txt`](configs/SW2.txt) — Access ports, trunking, VLANs, and management interface
- [`SW3.txt`](configs/SW3.txt) — Access ports, trunking, VLANs, and management interface

The text files are documentation copies. Before using them to rebuild the lab, verify that the commands match the saved Packet Tracer topology and the device models. Public copies should not contain real credentials.

## Verification and Testing

The lab's test plan is available in [`tests/TEST-PLAN.md`](tests/TEST-PLAN.md).

Previously observed results include:

- Clients received IP addresses through DHCP.
- Inter-VLAN communication between departmental clients succeeded.
- Guest clients were blocked from reaching IT and Administration clients.
- Guest clients successfully reached the external test address `203.0.113.1`.
- ACL counters showed matches on the Guest isolation rules.

These results describe the tests performed earlier. Re-run the tests against the current saved `.pkt` file before treating them as a final verification of the current configuration.

## Repository Structure

```text
Campus-Network-Engineering/
├── Campus-Network-Engineering.pkt
├── README.md
├── .gitignore
├── configs/
│   ├── R1.txt
│   ├── SW1.txt
│   ├── SW2.txt
│   └── SW3.txt
├── docs/
│   ├── IP-ADDRESSING.md
│   └── TOPOLOGY.md
├── tests/
│   └── TEST-PLAN.md
└── topology/
    ├── campus-topology.mmd
    └── campus-topology.png
```

## How to Open the Lab

1. Open Cisco Packet Tracer.
2. Open `Campus-Network-Engineering.pkt`.
3. Wait for the topology and devices to load.
4. Inspect the device configurations and links.
5. Run the tests in `tests/TEST-PLAN.md`.
6. Save a separate copy before making major configuration changes.

## Learning Outcomes

This project demonstrates practical understanding of enterprise campus networking, VLAN segmentation, trunk configuration, inter-VLAN routing, DHCP, OSPF, ACL-based traffic filtering, and network troubleshooting.

It can serve as a foundation for more advanced projects involving network automation with Python and Ansible, configuration validation, and NetDevOps workflows.


## Security and Public Release

- This public-ready archive intentionally excludes `Campus-Network-Engineering.pkt`. The Packet Tracer file is a proprietary binary and its embedded device configurations and credentials cannot be reliably scrubbed by editing the accompanying text files.
- Keep your original `.pkt` file privately. Before publishing a `.pkt` file, open it in Packet Tracer, inspect each device configuration, remove or replace credentials with unique lab-only credentials, save a separate sanitized copy, and verify it again.
- The `.txt` files under `configs/` are documentation copies and may need device-specific commands or credentials before they can be applied in a lab.
- Do not publish work or personal passwords, tokens, private keys, device serial numbers, or production configuration details.
