# Verification and Troubleshooting Plan

Run tests after the topology is cabled and device configs are applied. Save outputs/screenshots in this folder or in a `screenshots/` subfolder.

## 1. Layer 2 and VLAN checks

On SW1, SW2, and SW3:

```text
show vlan brief
show interfaces trunk
show interfaces status
```

Expected:
- VLANs 10, 20, 30, 40, and 99 exist on all switches.
- SW1–SW2 and SW1–SW3 links are trunking.
- PC-IT and PC-ADMIN are access ports in VLANs 10 and 20.
- PC-HR and PC-GUEST are access ports in VLANs 30 and 40.

## 2. Layer 3 checks

On SW1:

```text
show ip interface brief
show ip route
show ip ospf neighbor
show ip protocols
```

Expected:
- SVIs are up/up once each VLAN has an active access port and the VLAN is carried by a trunk.
- R1 should appear as an OSPF neighbor.
- The external test LAN `203.0.113.0/24` should be learned via OSPF.

On R1:

```text
show ip interface brief
show ip route
show ip ospf neighbor
```

Expected:
- `10.0.0.0/30` and `203.0.113.0/24` are connected.
- SW1 is an OSPF neighbor.

## 3. DHCP checks

Set each PC to Desktop > IP Configuration > DHCP.

On SW1:

```text
show ip dhcp binding
show ip dhcp pool
```

Expected:
- PC-IT receives `192.168.10.x/24`, gateway `192.168.10.1`.
- PC-ADMIN receives `192.168.20.x/24`, gateway `192.168.20.1`.
- PC-HR receives `192.168.30.x/24`, gateway `192.168.30.1`.
- PC-GUEST receives `192.168.40.x/24`, gateway `192.168.40.1`.

## 4. Connectivity and security matrix

| Source | Destination | Expected result | Reason |
|---|---|---|---|
| PC-IT | 192.168.10.1 | Pass | Local VLAN gateway |
| PC-IT | PC-ADMIN address | Pass | Inter-VLAN routing allowed by default |
| PC-HR | 192.168.30.1 | Pass | Local VLAN gateway |
| PC-GUEST | PC-IT address | Fail | Guest ACL denies internal 192.168.0.0/16 |
| PC-GUEST | 192.168.99.2 | Fail | Guest ACL denies management network |
| PC-IT | 203.0.113.10 | Pass | OSPF route to external test LAN |
| PC-GUEST | 203.0.113.10 | Pass | Guest ACL permits non-internal IPv4 destinations |

Use `ping <destination-ip>` from each PC's Command Prompt. Packet Tracer's first ping can fail while ARP resolves; repeat the ping before deciding the test failed.

## 5. External server setup

On SRV-EXT > Desktop > IP Configuration:
- IP address: `203.0.113.10`
- Subnet mask: `255.255.255.0`
- Default gateway: `203.0.113.1`
- DNS: optional for this lab

A successful ping tests routed reachability, not internet access. `203.0.113.0/24` is reserved for documentation and examples; it is only a simulated external segment here.

## 6. Troubleshooting checklist

- Check that all relevant interfaces are `no shutdown`.
- Confirm VLAN IDs exist on both ends of every trunk.
- Verify trunk allowed VLAN lists match.
- Confirm the PC is set to DHCP and its switch access port is in the correct VLAN.
- Confirm `ip routing` is enabled on SW1.
- Confirm the transit interfaces use `10.0.0.1/30` and `10.0.0.2/30`.
- Check OSPF neighbor state and routing tables.
- Confirm ACL direction is `in` on `Vlan40`.
- Check that each VLAN SVI is up/up; an SVI may remain down if the VLAN is inactive or not carried on a trunk.

## Results template

| Test | Expected | Actual | Pass/Fail | Notes |
|---|---|---|---|---|
| VLAN and trunk verification | All VLANs/trunks present | | | |
| DHCP VLAN 10 | 192.168.10.0/24 | | | |
| DHCP VLAN 20 | 192.168.20.0/24 | | | |
| DHCP VLAN 30 | 192.168.30.0/24 | | | |
| DHCP VLAN 40 | 192.168.40.0/24 | | | |
| OSPF neighbor | FULL | | | |
| IT to Administration | Pass | | | |
| Guest to IT | Fail | | | |
| Guest to external test server | Pass | | | |
